n = ARGV[0].to_i
num = "1"
acu = ""


n.times do |i| 

    acu += num 
    num = num.next
    print " #{acu} "
    
end