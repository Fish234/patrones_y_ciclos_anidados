n = ARGV[0].to_i


# LETRA O
# Parte superior
print "\n"
n.times do
    print "*"
end
print "\n"

# Parte del medio
(n - 2).times do
    print "*"
    (n - 2).times do
    print " "
    end
    print "*"
    print "\n"
end

# Parte inferior
n.times do
    print "*"
end
print "\n"

# LETRA I
# Parte superior
print "\n"
n.times do
    print "*"
    end
    print "\n"

# Parte del medio
(n - 2).times do
    print "  *"
(n - 2).times do
    print " "
    end
    print " "
    print "\n"
end

# Parte inferior
n.times do
    print "*"
end
print "\n"

#LETRA Z
# Parte superior
print "\n"
n.times do
    print "*"
end
print "\n"

# Parte del medio
(n-4).times do |i|
    (i - 4).times do 
        print "    "
        puts "*"
    end
    (n - 4).times do 
        print "   "
        puts "*"
    end    
    (n - 4).times do 
        print "  "
        puts "*"
    end
    (n - 4).times do 
        print " "
        puts "*"
    end
end

# Parte inferior
n.times do
    print "*"
end
print "\n"

#LETRA X
print "\n"
n.times do |i|
    n.times do |j|
        if i == j || j+i == n-1
            print "*"
        else
            print " "    
        end
    end    
    print "\n"
end
print "\n"

#Número 0
print "\n"
n.times do |i|
    print "*"
end
print "\n"
(n-2).times do |i|
    n.times do |j|
        if j == i +1
            print "*"
        elsif j == 0 || j == 4
            print "*"
        else
            print " "
        end
    end 
    print "\n"
end
n.times do |i|
    print "*"
end 
print "\n" 

#Arbol
#Esta linea enorme, es la copa del arbol :)
print "\n"
(n-4).times do
    print "   "
    (n-4).times do
        print "*"
    end
    print "\n"
    (n-4).times do
        print "  "
    end
    (n-4).times do
        print "*"
    end 
    (n-4).times do
        print " "
    end 
    (n-4).times do
        print "*"
    end
    print "\n"
    (n-4).times do
        print " "
    end
    (n-4).times do
        print "*"
    end
    (n-4).times do
        print " "
    end
    (n-4).times do
        print "*"
    end
    (n-4).times do
        print " "
    end
    (n-4).times do
        print "*"
    end
    print "\n"
    (n-4).times do
        print "*"
        print " "
    end
    (n-4).times do
        print "*"
        print " "
    end
    (n-4).times do
        print "*"
        print " "
    end
    (n-4).times do
        print "*"
    end
    print "\n"
end

#Tronco :)
(n-4).times do
    print "   "
    (n-4).times do
        print "*"
    end
    print "\n"
    (n-4).times do
        print "   "
    end
    (n-4).times do
        print "*"
    end
    print "\n"
end

#Raíz :)
(n-4).times do
    print " "
    (n-4).times do
        print "*"
    end
    (n-4).times do
        print " "
    end
    (n-4).times do
        print "*"
    end
    (n-4).times do
        print " "
    end
    (n-4).times do
        print "*"
    end
    print "\n"
end 
